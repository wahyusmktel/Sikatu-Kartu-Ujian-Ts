@extends('admin.layouts.app')

@section('page-title', 'Data Ujian')

@section('breadcrumbs')
    <li class="nav-home">
        <a href="/admin/dashboard">
            <i class="flaticon-home"></i>
        </a>
    </li>
    <li class="separator">
        <i class="flaticon-right-arrow"></i>
    </li>
    <li class="nav-item">
        <a href="/admin/dashboard">Dashboard</a>
    </li>
    <li class="separator">
        <i class="flaticon-right-arrow"></i>
    </li>
    <li class="nav-item">
        <a href="/admin/ujian">Data Ujian</a>
    </li>
@endsection

@section('content')
    <div class="page-category">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="pull-left">
                        <!-- Tombol untuk memicu modal -->
                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#tambahUjianModal">
                            <i class="fa fa-plus"></i> Tambah Data
                        </button>
                        </div>
                        <!-- Modal Tambah Data Ujian -->
                        <div class="modal fade" id="tambahUjianModal" tabindex="-1" role="dialog" aria-labelledby="tambahUjianModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="tambahUjianModalLabel">Tambah Data Ujian</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <form action="{{ route('admin.ujian.store') }}" method="post">
                                        @csrf
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label for="nama_ujian">Nama Ujian</label>
                                                <input type="text" class="form-control" id="nama_ujian" name="nama_ujian" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="kode_ujian">Kode Ujian</label>
                                                <input type="text" class="form-control" id="kode_ujian" name="kode_ujian" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="tahun_pelajaran">Tahun Pelajaran</label>
                                                <input type="text" class="form-control" id="tahun_pelajaran" name="tahun_pelajaran" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="semester">Semester</label>
                                                <select class="form-control" id="semester" name="semester" required>
                                                    <option value="1">Semester 1</option>
                                                    <option value="2">Semester 2</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="link_ujian">Link Ujian</label>
                                                <input type="text" class="form-control" id="link_ujian" name="link_ujian" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="tgl_mulai">Tanggal Mulai</label>
                                                <input type="date" class="form-control" id="tgl_mulai" name="tgl_mulai" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="tgl_akhir">Tanggal Akhir</label>
                                                <input type="date" class="form-control" id="tgl_akhir" name="tgl_akhir" required>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>


                        <div class="pull-right">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="collapse" id="search-nav">
                                <form class="navbar-form nav-search mr-md-3" action="{{ route('admin.siswa') }}" method="GET">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <button type="submit" class="btn btn-search pr-1">
                                                <i class="fa fa-search search-icon"></i>
                                            </button>
                                        </div>
                                        <input type="text" name="cari" placeholder="Search ..." class="form-control">
                                    </div>
                                </form>
                            </div>
                        </div>
                        </div>                
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Ujian</th>
                                    <th>Tahun Pelajaran</th>
                                    <th>Semester</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php $no = ($ujian->currentPage() - 1) * $ujian->perPage() + 1; @endphp
                                @forelse($ujian as $data)
                                <tr>
                                    <td>{{ $no++ }}</td>
                                    <td>{{ $data->nama_ujian }}</td>
                                    <td>{{ $data->tahun_pelajaran }}</td>
                                    <td>{{ $data->semester }}</td>
                                    <td>
                                        @if($data->status)
                                            <input type="checkbox" checked data-toggle="toggle" data-onstyle="primary" data-offstyle="danger" data-on="ON" data-off="OFF" class="status-toggle" data-id="{{ $data->id }}">
                                        @else
                                            <input type="checkbox" data-toggle="toggle" data-onstyle="primary" data-offstyle="danger" data-on="ON" data-off="OFF" class="status-toggle" data-id="{{ $data->id }}">
                                        @endif
                                    </td>                                    
                                    <td>
                                        <!-- Tombol Detail -->
                                        <button class="btn btn-info btn-sm" data-toggle="modal" data-target="#detailModal-{{ $data->id }}"><i class="fa fa-eye"></i> Detail</button>
                                        <!-- Modal Detail Ujian -->
                                        <div class="modal fade" id="detailModal-{{ $data->id }}" tabindex="-1" role="dialog" aria-labelledby="detailModalLabel-{{ $data->id }}" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="detailModalLabel-{{ $data->id }}">Detail Ujian: {{ $data->nama_ujian }}</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Nama Ujian: {{ $data->nama_ujian }}<br>
                                                        Tahun Pelajaran: {{ $data->tahun_pelajaran }}<br>
                                                        Semester: {{ $data->semester }}<br>
                                                        Link Ujian: {{ $data->link_ujian }}<br>
                                                        Tanggal Mulai: {{ $data->tgl_mulai }}<br>
                                                        Tanggal Akhir: {{ $data->tgl_akhir }}<br>
                                                        Status: {{ $data->status ? 'Aktif' : 'Tidak Aktif' }}<br>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="9">Data ujian tidak ditemukan.</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Cek jika ada pesan sukses dari session
            @if(session('success'))
                $.notify({
                    // Isi konten notifikasi
                    message: '{{ session('success') }}',
                    title: 'Sukses!',
                    icon: 'fa fa-check'
                }, {
                    type: 'success',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                    delay: 5000,
                });
            @endif

            // Cek jika ada pesan error dari session
            @if(session('error'))
                $.notify({
                    // Isi konten notifikasi
                    message: '{{ session('error') }}',
                    title: 'Error!',
                    icon: 'fa fa-exclamation-triangle'
                }, {
                    type: 'danger',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                    delay: 5000,
                });
            @endif
        });

    </script>


    <!-- Script Aktif -->
    <script>
        $(document).ready(function() {
            $('.status-toggle').change(function(e) {
                let ujianId = $(this).data('id');
                let status = $(this).prop('checked');
                let currentElement = $(this);  // Simpan referensi elemen saat ini

                // Konfirmasi SweetAlert
                swal({
                    title: status ? "Konfirmasi Aktivasi" : "Konfirmasi Non-Aktivasi",
                    text: status ? "Apakah Anda ingin mengaktifkan ujian?" : "Apakah Anda yakin akan menonaktifkan ujian?",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                }).then((willChange) => {
                    if (willChange) {
                        $.ajax({
                            url: '/admin/ujian/update-status/' + ujianId,
                            method: 'POST',
                            data: {
                                "_token": "{{ csrf_token() }}",
                                "status": status
                            },
                            success: function(response) {
                                if (response.success) {

                                    // Pilih pesan berdasarkan status
                                    let message = status ? 'Ujian berhasil diaktifkan.' : 'Ujian berhasil dinonaktifkan.';

                                    $.notify({
                                        message: message,
                                        title: 'Sukses!',
                                        icon: 'fa fa-check'
                                    }, {
                                        type: 'success',
                                        placement: {
                                            from: "top",
                                            align: "right"
                                        },
                                        time: 1000,
                                        delay: 5000,
                                    });
                                    setTimeout(function() {
                                        location.reload();
                                    }, 2000);
                                } else {
                                    $.notify({
                                        message: 'Terjadi kesalahan saat mengupdate status.',
                                        title: 'Error!',
                                        icon: 'fa fa-exclamation-triangle'
                                    }, {
                                        type: 'danger',
                                        placement: {
                                            from: "top",
                                            align: "right"
                                        },
                                        time: 1000,
                                        delay: 5000,
                                    });
                                    setTimeout(function() {
                                        location.reload();
                                    }, 2000);
                                }
                            }
                        });
                    } else {
                        // Jika pengguna membatalkan, kembalikan toggle ke posisi awal
                        currentElement.prop('checked', !status);
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    }
                });
            });
        });
    </script>
    
@endsection
