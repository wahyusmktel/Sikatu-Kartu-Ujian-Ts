@extends('admin.layouts.app')

@section('page-title', 'Data Siswa')

@section('breadcrumbs')
    <li class="nav-home">
        <a href="/admin/dashboard">
            <i class="flaticon-home"></i>
        </a>
    </li>
    <li class="separator">
        <i class="flaticon-right-arrow"></i>
    </li>
    <li class="nav-item">
        <a href="/admin/dashboard">Dashboard</a>
    </li>
    <li class="separator">
        <i class="flaticon-right-arrow"></i>
    </li>
    <li class="nav-item">
        <a href="/admin/siswa/">Data Siswa</a>
    </li>
@endsection

@section('content')
    <div class="page-category">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="pull-left">
                        <!-- Tombol untuk memicu modal -->
                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#importDataModal">
                            <i class="fa fa-file-excel"></i> Import Data
                        </button>
                        </div>
                        <!-- Modal -->
                        <div class="modal fade" id="importDataModal" tabindex="-1" role="dialog" aria-labelledby="importDataModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="importDataModalLabel">Import Data Siswa</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <!-- Formulir untuk meng-upload file Excel -->
                                        <form action="{{ route('admin.siswa.import') }}" method="post" enctype="multipart/form-data">
                                            @csrf
                                            <div class="form-group">
                                                <label for="file">Pilih File Excel:</label>
                                                <input type="file" name="file" id="file" class="form-control">
                                            </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-success btn-sm"><i class="fa fa-upload"></i> Upload dan Import</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="pull-right">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="collapse" id="search-nav">
                                <form class="navbar-form nav-search mr-md-3" action="{{ route('admin.siswa') }}" method="GET">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <button type="submit" class="btn btn-search pr-1">
                                                <i class="fa fa-search search-icon"></i>
                                            </button>
                                        </div>
                                        <input type="text" name="cari" placeholder="Search ..." class="form-control">
                                    </div>
                                </form>
                            </div>
                        </div>
                        </div>                
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama</th>
                                    <th>NIPD</th>
                                    <th>NISN</th>
                                    <th>Email</th>
                                    <th>NIK</th>
                                    <th>Aksi</th>
                                    <!-- Anda dapat menambahkan kolom lain sesuai kebutuhan -->
                                </tr>
                            </thead>
                            <tbody>
                                @php $no = ($siswa->currentPage() - 1) * $siswa->perPage() + 1; @endphp
                                @forelse($siswa as $data)
                                <tr>
                                    <td>{{ $no++ }}</td>
                                    <td>{{ $data->nama }}</td>
                                    <td>{{ $data->nipd }}</td>
                                    <td>{{ $data->nisn }}</td>
                                    <td>{{ $data['e-mail'] }}</td> <!-- Pastikan nama kolom di database e_mail bukan e-mail -->
                                    <td>{{ $data->nik }}</td>
                                    <td>
                                        <!-- Tombol Detail -->
                                        <button class="btn btn-info btn-sm" data-toggle="modal" data-target="#detailModal-{{ $data->id }}"><i class="fa fa-eye"></i> Detail</button>
                                        <!-- Modal Detail Siswa -->
                                        <div class="modal fade" id="detailModal-{{ $data->id }}" tabindex="-1" role="dialog" aria-labelledby="detailModalLabel-{{ $data->id }}" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="detailModalLabel-{{ $data->id }}">Detail Siswa: {{ $data->nama }}</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Nama: {{ $data->nama }}<br>
                                                        NIPD: {{ $data->nipd }}<br>
                                                        NISN: {{ $data->nisn }}<br>
                                                        Email: {{ $data['e-mail'] }}<br>
                                                        NIK: {{ $data->nik }}<br>
                                                        <!-- Tambahkan detail lainnya sesuai kebutuhan -->
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="5">Data siswa tidak ditemukan.</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                        <!-- Paginasi -->
                        {{ $siswa->appends(['cari' => $cari])->links('vendor.pagination.custom') }}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Cek jika ada pesan sukses dari session
            @if(session('success'))
                $.notify({
                    // Isi konten notifikasi
                    message: '{{ session('success') }}',
                    title: 'Sukses!',
                    icon: 'fa fa-check'
                }, {
                    type: 'success',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                    delay: 5000,
                });
            @endif

            // Cek jika ada pesan error dari session
            @if(session('error'))
                $.notify({
                    // Isi konten notifikasi
                    message: '{{ session('error') }}',
                    title: 'Error!',
                    icon: 'fa fa-exclamation-triangle'
                }, {
                    type: 'danger',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                    delay: 5000,
                });
            @endif
        });

    </script>
    
@endsection
