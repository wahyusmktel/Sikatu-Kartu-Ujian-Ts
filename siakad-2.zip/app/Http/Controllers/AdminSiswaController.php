<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\AdminSiswa;
use App\Imports\SiswaImport;
use Maatwebsite\Excel\Facades\Excel;

class AdminSiswaController extends Controller
{
    public function show()
    {
        return view('admin.siswa');
    }

    public function importExcel(Request $request)
    {
        try {
            // Validasi file yang di-upload adalah file Excel
            $request->validate([
                'file' => 'required|mimes:xlsx,xls'
            ], [
                'file.required' => 'File harus dipilih terlebih dahulu.',
                'file.mimes' => 'Format file tidak valid. Hanya file xlsx dan xls yang diperbolehkan.'
            ]);

            // Mengimport data
            Excel::import(new SiswaImport, $request->file('file'));

            return redirect()->back()->with('success', 'Data berhasil diimpor!');

        } catch (\Exception $e) {
            // Menangkap kesalahan dan mengembalikan pesan kesalahan
            return redirect()->back()->with('error', 'Terjadi kesalahan saat mengimpor data: ' . $e->getMessage());
        }
    }

    public function index(Request $request)
    {
        $cari = $request->cari; // Parameter pencarian

        $cariLower = strtolower("%$cari%");

        $dataPerPage = $request->input('dataPerPage', 10); // Jumlah data per halaman, default adalah 10

        // Query pencarian
        $siswa = AdminSiswa::when($cari, function($query) use ($cariLower) {
            return $query->whereRaw('LOWER(nama) LIKE ?', [$cariLower])
                        ->orWhereRaw('LOWER(nisn) LIKE ?', [$cariLower])
                        ->orWhereRaw('LOWER(nipd) LIKE ?', [$cariLower])
                        ->orWhereRaw('LOWER("e-mail") LIKE ?', [$cariLower])
                        ->orWhereRaw('LOWER(nik) LIKE ?', [$cariLower]);
        })
        ->paginate($dataPerPage);

        return view('admin.siswa', compact('siswa', 'cari'));
    }

}