

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>KARTU PESERTA UJIAN - <?php echo e($kartu->siswa->nama); ?></title>

    
</head>

<body>
<style>
    html, body {
        min-height: 842px;
        font-family: "Roboto";
        font-size: 14px;
    }
    .value {
        text-align: left;
        width: 50%;
    }
    table {
        width: 100%;
    }
    .foto {
        border: 1px solid black !important;
        width: 120px;
        height: 150px;
        padding: 5px;
    }
    small {
        font-size: 10px;
        font-weight: normal;
    }
</style>

<div class="sheet padding-15mm">
    <div class="content">
        <table>
            <tr>
                <td style="text-align: left;">
                    <img width="130px" class="img-fluid" src="https://cdn2.ypt.or.id/ppdb/images/ts.png" alt="">
                </td>
                <td width="60%" style="text-align: center; font-size: 15px;">
                    <b>
                        KARTU PESERTA UJIAN<br>
                        <?php echo e($kartu->ujian->nama_ujian); ?> <?php echo e($kartu->ujian->semester); ?> Tahun Pelajaran <?php echo e($kartu->ujian->tahun_pelajaran); ?><br>
                    </b><br>
                </td>
                <td style="text-align: right;">
                    <img width="100px" class="img-fluid" src="https://cdn2.ypt.or.id/ppdb/images/ypt.png" alt="">
                </td>
            </tr>
        </table>
        <hr>
        <br>
        <table>
            <tr>
                <td width="80%">
                    <table>
                        <tbody>
                        <tr>
                            <th colspan="3" style="text-align: left">DATA IDENTITAS</th>
                        </tr>
                        <tr>
                            <td width="15%">Nama Siswa</td>
                            <td width="1%">:</td>
                            <td class="value"><?php echo e($kartu->siswa->nama); ?></td>
                        </tr>
                        <tr>
                            <td>Kelas</td>
                            <td>:</td>
                            <td class="value"><?php echo e($kartu->siswa->rombel_saat_ini); ?></td>
                        </tr>
                        <tr>
                            <td>Username Ujian</td>
                            <td>:</td>
                            <td class="value"><?php echo e($kartu->username_ujian); ?></td>
                        </tr>
                        <tr>
                            <td>Password Ujian</td>
                            <td>:</td>
                            <td class="value"><?php echo e($kartu->password_ujian); ?></td>
                        </tr>
                        <tr>
                            <td>Nama Ujian</td>
                            <td>:</td>
                            <td class="value"><?php echo e($kartu->ujian->nama_ujian); ?> <?php echo e($kartu->ujian->semester); ?> Tahun Pelajaran <?php echo e($kartu->ujian->tahun_pelajaran); ?></td>
                        </tr>
                        <tr>
                            <td>Link Ujian</td>
                            <td>:</td>
                            <td class="value"><?php echo e($kartu->ujian->link_ujian); ?></td>
                        </tr>
                        <tr>
                            <td>Tanggal Mulai</td>
                            <td>:</td>
                            <td class="value"><?php echo e($kartu->ujian->tgl_mulai); ?></td>
                        </tr>
                        <tr>
                            <td>Tanggal Akhir</td>
                            <td>:</td>
                            <td class="value"><?php echo e($kartu->ujian->tgl_akhir); ?></td>
                        </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </table>
        <br>
        <table>
            <tr>
                <td width="70%">
                    <p><h3>CATATAN :</h3></p>
                    <p>Silahkan gunakan informasi diatas untuk login di dalam aplikasi ujian, apabila terdapat masalah dalam melakukan login ke dalam aplikasi silahkan dapat menghubungi pengawas ruang masing - masing.
                    Untuk link ujian dapat berubah sewaktu - waktu, perubahan akan di informasikan oleh pengawas ruang.</p><br><br><p>Dicetak oleh: <?php echo e($kartu->siswa->nama); ?> pada <?php echo e($tanggalCetak); ?></p>
                </td>
                
            </tr>
        </table>
    </div>
</div>

</body>
</html>
<?php /**PATH C:\Laravel\sikatu\resources\views/admin/cetak_kartu.blade.php ENDPATH**/ ?>