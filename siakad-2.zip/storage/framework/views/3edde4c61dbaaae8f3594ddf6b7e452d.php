

<?php $__env->startSection('page-title', 'Kartu Ujian'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="nav-home">
        <a href="/siswa/dashboard">
            <i class="flaticon-home"></i>
        </a>
    </li>
    <li class="separator">
        <i class="flaticon-right-arrow"></i>
    </li>
    <li class="nav-item">
        <a href="/siswa/kartu">Kartu Ujian</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-category">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">

                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Ujian</th>
                                    <th>Tanggal Download Kartu</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = ($kartuUjians->currentPage() - 1) * $kartuUjians->perPage() + 1; ?>
                                <?php $__empty_1 = true; $__currentLoopData = $kartuUjians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kartu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($kartu->ujian->nama_ujian); ?></td>
                                    <td><?php echo e($kartu->tgl_download_kartu); ?></td>
                                    <td>
                                        <?php if($kartu->ujian->status): ?>
                                            <span class="badge badge-success">Aktif</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Non-Aktif</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('kartu.cetak_siswa', $kartu->id_kartu)); ?>" class="btn btn-primary btn-sm" target="_blank"><i class="fa fa-print"></i> Cetak</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    
                                    <td colspan="5">
                                        Belum ada data kartu ujian untuk ujian yang aktif. 
                                        <?php if($lastKartuForSiswa): ?>
                                            Silahkan Hubungi admin <a href="https://wa.me/6282372605566?text=Hai%2C%20Nama%20saya%20<?php echo e($lastKartuForSiswa->siswa->nama); ?>%20dari%20kelas%20<?php echo e($lastKartuForSiswa->siswa->rombel_saat_ini); ?>%20ingin%20melakukan%20aktivasi%20kartu%20ujian%20pada%20<?php echo e($lastKartuForSiswa->ujian->nama_ujian); ?>.%20Terimakasih.">Klik Disini</a>
                                        <?php else: ?>
                                            Silahkan Hubungi admin untuk informasi lebih lanjut.
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <!-- Paginasi -->
                        <?php echo e($kartuUjians->appends(['cari' => $cari])->links('vendor.pagination.custom')); ?>                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Cek jika ada pesan sukses dari session
            <?php if(session('success')): ?>
                $.notify({
                    // Isi konten notifikasi
                    message: '<?php echo e(session('success')); ?>',
                    title: 'Sukses!',
                    icon: 'fa fa-check'
                }, {
                    type: 'success',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                    delay: 5000,
                });
            <?php endif; ?>

            // Cek jika ada pesan error dari session
            <?php if(session('error')): ?>
                $.notify({
                    // Isi konten notifikasi
                    message: '<?php echo e(session('error')); ?>',
                    title: 'Error!',
                    icon: 'fa fa-exclamation-triangle'
                }, {
                    type: 'danger',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                    delay: 5000,
                });
            <?php endif; ?>
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('siswa.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\sikatu\resources\views/siswa/kartu.blade.php ENDPATH**/ ?>