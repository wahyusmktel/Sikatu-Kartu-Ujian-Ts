

<?php $__env->startSection('page-title', 'Settings'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="nav-home">
        <a href="/admin/dashboard">
            <i class="flaticon-home"></i>
        </a>
    </li>
    <li class="separator">
        <i class="flaticon-right-arrow"></i>
    </li>
    <li class="nav-item">
        <a href="/admin/dashboard">Dashboard</a>
    </li>
    <li class="separator">
        <i class="flaticon-right-arrow"></i>
    </li>
    <li class="nav-item">
        <a href="/admin/settings/">Settings</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-category">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                                    
                    </div>
                    <div class="card-body">
                        <?php if($settings): ?>
                        <form action="<?php echo e(route('settings.update')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="nama_sekolah">Nama Sekolah:</label>
                                <input type="text" class="form-control" id="nama_sekolah" name="nama_sekolah" value="<?php echo e($settings->nama_sekolah); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="nama_kepsek">Nama Kepsek:</label>
                                <input type="text" class="form-control" id="nama_kepsek" name="nama_kepsek" value="<?php echo e($settings->nama_kepsek); ?>" required>
                            </div>
                    
                            <div class="form-group">
                                <label for="no_hp_sekolah">No HP Sekolah:</label>
                                <input type="text" class="form-control" id="no_hp_sekolah" name="no_hp_sekolah" value="<?php echo e($settings->no_hp_sekolah); ?>" required>
                            </div>
                    
                            <div class="form-group">
                                <label for="email_sekolah">Email Sekolah:</label>
                                <input type="email" class="form-control" id="email_sekolah" name="email_sekolah" value="<?php echo e($settings->email_sekolah); ?>" required>
                            </div>
                    
                            <div class="form-group">
                                <label for="npsn">NPSN:</label>
                                <input type="text" class="form-control" id="npsn" name="npsn" value="<?php echo e($settings->npsn); ?>" required>
                            </div>
                    
                            <div class="form-group">
                                <label for="alamat_sekolah">Alamat Sekolah:</label>
                                <textarea class="form-control" id="alamat_sekolah" name="alamat_sekolah" required><?php echo e($settings->alamat_sekolah); ?></textarea>
                            </div>
                    
                            <div class="form-group">
                                <label for="logo_sekolah">Logo Sekolah:</label><br>
                                <img src="<?php echo e(asset('storage/' . $settings->logo_sekolah)); ?>" width="100" alt="Logo Sekolah"><br><br>
                                <input type="file" id="logo_sekolah" name="logo_sekolah">
                                <small class="text-muted">Biarkan kosong jika tidak ingin mengganti logo</small>
                            </div>
                    
                            <button type="submit" class="btn btn-primary">Perbarui</button>

                        <?php else: ?>
                        <p>Settings belum diatur. Silakan buat setting terlebih dahulu.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Cek jika ada pesan sukses dari session
            <?php if(session('success')): ?>
                $.notify({
                    // Isi konten notifikasi
                    message: '<?php echo e(session('success')); ?>',
                    title: 'Sukses!',
                    icon: 'fa fa-check'
                }, {
                    type: 'success',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                    delay: 5000,
                });
            <?php endif; ?>

            // Cek jika ada pesan error dari session
            <?php if(session('error')): ?>
                $.notify({
                    // Isi konten notifikasi
                    message: '<?php echo e(session('error')); ?>',
                    title: 'Error!',
                    icon: 'fa fa-exclamation-triangle'
                }, {
                    type: 'danger',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                    delay: 5000,
                });
            <?php endif; ?>
        });

    </script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\sikatu\resources\views/admin/settings.blade.php ENDPATH**/ ?>