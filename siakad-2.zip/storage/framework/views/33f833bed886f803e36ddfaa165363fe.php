

<?php $__env->startSection('page-title', 'Data Siswa'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="nav-home">
        <a href="/admin/dashboard">
            <i class="flaticon-home"></i>
        </a>
    </li>
    <li class="separator">
        <i class="flaticon-right-arrow"></i>
    </li>
    <li class="nav-item">
        <a href="/admin/dashboard">Dashboard</a>
    </li>
    <li class="separator">
        <i class="flaticon-right-arrow"></i>
    </li>
    <li class="nav-item">
        <a href="/admin/siswa/10/1">Data Siswa</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-category">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="pull-left">
                        <!-- Tombol untuk memicu modal -->
                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#importDataModal">
                            <i class="fa fa-file-excel"></i> Import Data
                        </button>
                        </div>
                        <!-- Modal -->
                        <div class="modal fade" id="importDataModal" tabindex="-1" role="dialog" aria-labelledby="importDataModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="importDataModalLabel">Import Data Siswa</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <!-- Formulir untuk meng-upload file Excel -->
                                        <form action="<?php echo e(route('admin.siswa.import')); ?>" method="post" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="file">Pilih File Excel:</label>
                                                <input type="file" name="file" id="file" class="form-control">
                                            </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-success btn-sm"><i class="fa fa-upload"></i> Upload dan Import</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="pull-right">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="collapse" id="search-nav">
                                <form class="navbar-form nav-search mr-md-3" action="<?php echo e(route('admin.siswa')); ?>" method="GET">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <button type="submit" class="btn btn-search pr-1">
                                                <i class="fa fa-search search-icon"></i>
                                            </button>
                                        </div>
                                        <input type="text" name="cari" placeholder="Search ..." class="form-control">
                                    </div>
                                </form>
                            </div>
                        </div>
                        </div>                
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama</th>
                                    <th>NIPD</th>
                                    <th>NISN</th>
                                    <th>Email</th>
                                    <th>NIK</th>
                                    <th>Aksi</th>
                                    <!-- Anda dapat menambahkan kolom lain sesuai kebutuhan -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = ($siswa->currentPage() - 1) * $siswa->perPage() + 1; ?>
                                <?php $__empty_1 = true; $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($data->nama); ?></td>
                                    <td><?php echo e($data->nipd); ?></td>
                                    <td><?php echo e($data->nisn); ?></td>
                                    <td><?php echo e($data->e_mail); ?></td> <!-- Pastikan nama kolom di database e_mail bukan e-mail -->
                                    <td><?php echo e($data->nik); ?></td>
                                    <td>
                                        <!-- Tombol Detail -->
                                        <button class="btn btn-info btn-sm" data-toggle="modal" data-target="#detailModal-<?php echo e($data->id); ?>"><i class="fa fa-eye"></i> Detail</button>
                                        <!-- Modal Detail Siswa -->
                                        <div class="modal fade" id="detailModal-<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="detailModalLabel-<?php echo e($data->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="detailModalLabel-<?php echo e($data->id); ?>">Detail Siswa: <?php echo e($data->nama); ?></h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Nama: <?php echo e($data->nama); ?><br>
                                                        NIPD: <?php echo e($data->nipd); ?><br>
                                                        NISN: <?php echo e($data->nisn); ?><br>
                                                        Email: <?php echo e($data->e_mail); ?><br>
                                                        NIK: <?php echo e($data->nik); ?><br>
                                                        <!-- Tambahkan detail lainnya sesuai kebutuhan -->
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5">Data siswa tidak ditemukan.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <!-- Paginasi -->
                        <?php echo e($siswa->appends(['cari' => $cari])->links('vendor.pagination.custom')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Cek jika ada pesan sukses dari session
            <?php if(session('success')): ?>
                $.notify({
                    // Isi konten notifikasi
                    message: '<?php echo e(session('success')); ?>',
                    title: 'Sukses!',
                    icon: 'fa fa-check'
                }, {
                    type: 'success',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                    delay: 5000,
                });
            <?php endif; ?>

            // Cek jika ada pesan error dari session
            <?php if(session('error')): ?>
                $.notify({
                    // Isi konten notifikasi
                    message: '<?php echo e(session('error')); ?>',
                    title: 'Error!',
                    icon: 'fa fa-exclamation-triangle'
                }, {
                    type: 'danger',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                    delay: 5000,
                });
            <?php endif; ?>
        });

    </script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\sikatu\sikatu\resources\views/admin/siswa.blade.php ENDPATH**/ ?>