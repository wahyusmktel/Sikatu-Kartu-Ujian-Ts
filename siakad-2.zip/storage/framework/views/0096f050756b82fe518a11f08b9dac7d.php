

<?php $__env->startSection('page-title', 'Aktivasi Kartu Ujian'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="nav-home">
        <a href="/admin/dashboard">
            <i class="flaticon-home"></i>
        </a>
    </li>
    <li class="separator">
        <i class="flaticon-right-arrow"></i>
    </li>
    <li class="nav-item">
        <a href="/admin/dashboard">Dashboard</a>
    </li>
    <li class="separator">
        <i class="flaticon-right-arrow"></i>
    </li>
    <li class="nav-item">
        <a href="/admin/aktivasi_kartu/">Aktivasi Kartu Ujian</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-category">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="pull-left">
                            <div class="form-group">
                                <label>Filter Aktivasi</label>
                                <div class="select2-input">
                                    <form action="<?php echo e(route('admin.aktivasi')); ?>" method="GET">
                                        <select id="filterAktivasi" name="status_filter" class="form-control" onchange="this.form.submit()">
                                            <option value="">- Pilih Status Aktivasi -</option>
                                            <option value="true" <?php echo e(request('status_filter') == 'true' ? 'selected' : ''); ?>>Sudah Aktivasi</option>
                                            <option value="false" <?php echo e(request('status_filter') == 'false' ? 'selected' : ''); ?>>Belum Aktivasi</option>
                                        </select>
                                    </form>
                                </div>
                            </div>
                            
                         </div>
                         
                                               
                        <div class="pull-right">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="collapse" id="search-nav">
                                    <form class="navbar-form nav-search mr-md-3" action="<?php echo e(route('admin.aktivasi')); ?>" method="GET">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <button type="submit" class="btn btn-search pr-1">
                                                    <i class="fa fa-search search-icon"></i>
                                                </button>
                                            </div>
                                            <input type="text" name="cari" value="<?php echo e($cari ?? ''); ?>" placeholder="Search ..." class="form-control">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>                
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Ujian</th>
                                    <th>Nama Siswa</th>
                                    <th>Kelas</th>
                                    
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = ($kartuUjians->currentPage() - 1) * $kartuUjians->perPage() + 1; ?>
                                <?php $__empty_1 = true; $__currentLoopData = $kartuUjians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kartu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($kartu->ujian->nama_ujian); ?> <?php echo e($kartu->ujian->semester); ?> Tahun Pelajaran <?php echo e($kartu->ujian->tahun_pelajaran); ?></td>
                                    <td><?php echo e($kartu->siswa->nama); ?></td>
                                    <td><?php echo e($kartu->siswa->rombel_saat_ini); ?></td>
                                    
                                    <td>
                                        <?php if($kartu->aktivasiKartu): ?>
                                            <?php if($kartu->aktivasiKartu->status_aktivasi): ?>
                                                <span class="badge badge-success">Sudah Aktivasi</span>
                                            <?php else: ?>
                                                <span class="badge badge-danger">Belum Aktivasi</span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Belum Aktivasi</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        
                                        <!-- Tombol Detail -->
                                        <?php
                                            $statusAktivasi = optional($kartu->aktivasiKartu)->status_aktivasi ?? false;
                                        ?>
                                        <input type="checkbox" data-toggle="toggle" data-onstyle="primary" data-offstyle="danger" data-on="ON" data-off="OFF" class="status-toggle" data-id="<?php echo e($kartu->id); ?>" data-id-kartu="<?php echo e($kartu->id); ?>" data-id-ujian="<?php echo e($kartu->id_ujian); ?>" data-id-siswa="<?php echo e($kartu->id_siswa); ?>" <?php echo e($statusAktivasi ? 'checked' : ''); ?>>

                                        <button class="btn btn-info btn-sm" data-toggle="modal" data-target="#detailModal-<?php echo e($kartu->id); ?>"><i class="fa fa-eye"></i> Detail</button>
                                        
                                        <?php
                                            $isActivated = $kartu->aktivasiKartu && $kartu->aktivasiKartu->status_aktivasi;
                                        ?>

                                        <?php if($isActivated): ?>
                                            <a href="<?php echo e(route('kartu.cetak', $kartu->id)); ?>" class="btn btn-primary btn-sm" target="_blank"><i class="fa fa-print"></i> Cetak</a>
                                        <?php else: ?>
                                            <button class="btn btn-primary btn-sm" disabled><i class="fa fa-print"></i> Cetak</button>
                                        <?php endif; ?>
                                        <!-- Modal Detail Kartu Ujian -->
                                        <div class="modal fade" id="detailModal-<?php echo e($kartu->id); ?>" tabindex="-1" role="dialog" aria-labelledby="detailModalLabel-<?php echo e($kartu->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="detailModalLabel-<?php echo e($kartu->id); ?>">Detail Kartu Ujian: <?php echo e($kartu->siswa->nama); ?></h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Nama Ujian: <?php echo e($kartu->ujian->nama_ujian); ?><br>
                                                        Nama Siswa: <?php echo e($kartu->siswa->nama); ?><br>
                                                        Username Ujian: <?php echo e($kartu->username_ujian); ?><br>
                                                        Password Ujian: <?php echo e($kartu->password_ujian); ?><br>
                                                        Status Data: 
                                                        <?php if($kartu->aktivasiKartu): ?>
                                                            <?php if($kartu->aktivasiKartu->status_aktivasi): ?>
                                                                <span class="badge badge-success">Sudah Aktivasi</span>
                                                            <?php else: ?>
                                                                <span class="badge badge-danger">Belum Aktivasi</span>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <span class="badge badge-danger">Belum Aktivasi</span>
                                                        <?php endif; ?>
                                                        <!-- Anda dapat menambahkan detail lainnya sesuai kebutuhan -->
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7">Belum ada data kartu ujian didalam ujian aktif.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <!-- Paginasi -->
                        
                        <?php echo e($kartuUjians->appends(['cari' => $cari, 'status_filter' => $statusFilter])->links('vendor.pagination.custom')); ?>                         
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Cek jika ada pesan sukses dari session
            <?php if(session('success')): ?>
                $.notify({
                    // Isi konten notifikasi
                    message: '<?php echo e(session('success')); ?>',
                    title: 'Sukses!',
                    icon: 'fa fa-check'
                }, {
                    type: 'success',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                    delay: 5000,
                });
            <?php endif; ?>

            // Cek jika ada pesan error dari session
            <?php if(session('error')): ?>
                $.notify({
                    // Isi konten notifikasi
                    message: '<?php echo e(session('error')); ?>',
                    title: 'Error!',
                    icon: 'fa fa-exclamation-triangle'
                }, {
                    type: 'danger',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                    delay: 5000,
                });
            <?php endif; ?>
        });

    </script>

    <script>
        $(document).ready(function() {
            $('.status-toggle').change(function(e) {
                let kartuId = $(this).data('id-kartu');
                let ujianId = $(this).data('id-ujian');
                let siswaId = $(this).data('id-siswa');
                let status = $(this).prop('checked');
                let currentElement = $(this);  // Simpan referensi elemen saat ini

                // Konfirmasi SweetAlert
                swal({
                    title: status ? "Konfirmasi Aktivasi" : "Konfirmasi Non-Aktivasi",
                    text: status ? "Apakah Anda ingin mengaktifkan kartu ujian?" : "Apakah Anda yakin akan menonaktifkan kartu ujian?",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                }).then((willChange) => {
                    if (willChange) {
                        $.ajax({
                            url: '/admin/aktivasi_kartu', // Sesuaikan dengan URL endpoint Anda
                            method: 'POST',
                            data: {
                                "_token": "<?php echo e(csrf_token()); ?>",
                                "id_kartu": kartuId,
                                "id_ujian": ujianId,
                                "id_siswa": siswaId,
                                "status_aktivasi": status
                            },
                            success: function(response) {
                                if (response.success) {
                                    let message = 'Kartu ujian berhasil diaktifkan.';
                                    $.notify({
                                        message: message,
                                        title: 'Sukses!',
                                        icon: 'fa fa-check'
                                    }, {
                                        type: 'success',
                                        placement: {
                                            from: "top",
                                            align: "right"
                                        },
                                        time: 1000,
                                        delay: 5000,
                                    });
                                } else {
                                    $.notify({
                                        // message: response.message || 'Terjadi kesalahan saat mengupdate status.',
                                        message: response.message || 'Kartu Ujian Berhasil di non-aktifkan.',
                                        title: 'Sukses!',
                                        icon: 'fa fa-exclamation-triangle'
                                    }, {
                                        type: 'danger',
                                        placement: {
                                            from: "top",
                                            align: "right"
                                        },
                                        time: 1000,
                                        delay: 5000,
                                    });
                                }
                                setTimeout(function() {
                                    location.reload();
                                }, 2000);
                            }
                        });
                    } else {
                        // Jika pengguna membatalkan, kembalikan toggle ke posisi awal
                        currentElement.prop('checked', !status);
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    }
                });
            });
        });

    </script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\sikatu\resources\views/admin/aktivasi.blade.php ENDPATH**/ ?>