

<?php $__env->startSection('page-title', 'Data Ujian'); ?>

<?php $__env->startSection('breadcrumbs'); ?>
    <li class="nav-home">
        <a href="/admin/dashboard">
            <i class="flaticon-home"></i>
        </a>
    </li>
    <li class="separator">
        <i class="flaticon-right-arrow"></i>
    </li>
    <li class="nav-item">
        <a href="/admin/dashboard">Dashboard</a>
    </li>
    <li class="separator">
        <i class="flaticon-right-arrow"></i>
    </li>
    <li class="nav-item">
        <a href="/admin/ujian">Data Ujian</a>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-category">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="pull-left">
                        <!-- Tombol untuk memicu modal -->
                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#tambahUjianModal">
                            <i class="fa fa-plus"></i> Tambah Data
                        </button>
                        </div>
                        <!-- Modal Tambah Data Ujian -->
                        <div class="modal fade" id="tambahUjianModal" tabindex="-1" role="dialog" aria-labelledby="tambahUjianModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="tambahUjianModalLabel">Tambah Data Ujian</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <form action="<?php echo e(route('admin.ujian.store')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label for="nama_ujian">Nama Ujian</label>
                                                <input type="text" class="form-control" id="nama_ujian" name="nama_ujian" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="tahun_pelajaran">Tahun Pelajaran</label>
                                                <input type="text" class="form-control" id="tahun_pelajaran" name="tahun_pelajaran" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="semester">Semester</label>
                                                <select class="form-control" id="semester" name="semester" required>
                                                    <option value="1">Semester 1</option>
                                                    <option value="2">Semester 2</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="link_ujian">Link Ujian</label>
                                                <input type="text" class="form-control" id="link_ujian" name="link_ujian" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="tgl_mulai">Tanggal Mulai</label>
                                                <input type="date" class="form-control" id="tgl_mulai" name="tgl_mulai" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="tgl_akhir">Tanggal Akhir</label>
                                                <input type="date" class="form-control" id="tgl_akhir" name="tgl_akhir" required>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>


                        <div class="pull-right">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="collapse" id="search-nav">
                                <form class="navbar-form nav-search mr-md-3" action="<?php echo e(route('admin.siswa')); ?>" method="GET">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <button type="submit" class="btn btn-search pr-1">
                                                <i class="fa fa-search search-icon"></i>
                                            </button>
                                        </div>
                                        <input type="text" name="cari" placeholder="Search ..." class="form-control">
                                    </div>
                                </form>
                            </div>
                        </div>
                        </div>                
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Ujian</th>
                                    <th>Tahun Pelajaran</th>
                                    <th>Semester</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = ($ujian->currentPage() - 1) * $ujian->perPage() + 1; ?>
                                <?php $__empty_1 = true; $__currentLoopData = $ujian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($data->nama_ujian); ?></td>
                                    <td><?php echo e($data->tahun_pelajaran); ?></td>
                                    <td><?php echo e($data->semester); ?></td>
                                    <td>
                                        <?php if($data->status): ?>
                                            <input type="checkbox" checked data-toggle="toggle" data-onstyle="primary" data-offstyle="danger" data-on="ON" data-off="OFF" class="status-toggle" data-id="<?php echo e($data->id); ?>">
                                        <?php else: ?>
                                            <input type="checkbox" data-toggle="toggle" data-onstyle="primary" data-offstyle="danger" data-on="ON" data-off="OFF" class="status-toggle" data-id="<?php echo e($data->id); ?>">
                                        <?php endif; ?>
                                    </td>                                    
                                    <td>
                                        <!-- Tombol Detail -->
                                        <button class="btn btn-info btn-sm" data-toggle="modal" data-target="#detailModal-<?php echo e($data->id); ?>"><i class="fa fa-eye"></i> Detail</button>
                                        <!-- Modal Detail Ujian -->
                                        <div class="modal fade" id="detailModal-<?php echo e($data->id); ?>" tabindex="-1" role="dialog" aria-labelledby="detailModalLabel-<?php echo e($data->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="detailModalLabel-<?php echo e($data->id); ?>">Detail Ujian: <?php echo e($data->nama_ujian); ?></h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Nama Ujian: <?php echo e($data->nama_ujian); ?><br>
                                                        Tahun Pelajaran: <?php echo e($data->tahun_pelajaran); ?><br>
                                                        Semester: <?php echo e($data->semester); ?><br>
                                                        Link Ujian: <?php echo e($data->link_ujian); ?><br>
                                                        Tanggal Mulai: <?php echo e($data->tgl_mulai); ?><br>
                                                        Tanggal Akhir: <?php echo e($data->tgl_akhir); ?><br>
                                                        Status: <?php echo e($data->status ? 'Aktif' : 'Tidak Aktif'); ?><br>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="9">Data ujian tidak ditemukan.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Cek jika ada pesan sukses dari session
            <?php if(session('success')): ?>
                $.notify({
                    // Isi konten notifikasi
                    message: '<?php echo e(session('success')); ?>',
                    title: 'Sukses!',
                    icon: 'fa fa-check'
                }, {
                    type: 'success',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                    delay: 5000,
                });
            <?php endif; ?>

            // Cek jika ada pesan error dari session
            <?php if(session('error')): ?>
                $.notify({
                    // Isi konten notifikasi
                    message: '<?php echo e(session('error')); ?>',
                    title: 'Error!',
                    icon: 'fa fa-exclamation-triangle'
                }, {
                    type: 'danger',
                    placement: {
                        from: "top",
                        align: "right"
                    },
                    time: 1000,
                    delay: 5000,
                });
            <?php endif; ?>
        });

    </script>


    <!-- Script Aktif -->
    <script>
        $(document).ready(function() {
            $('.status-toggle').change(function() {
                let ujianId = $(this).data('id');
                let status = $(this).prop('checked');
    
                $.ajax({
                    url: '/admin/ujian/update-status/' + ujianId,
                    method: 'POST',
                    data: {
                        "_token": "<?php echo e(csrf_token()); ?>",
                        "status": status
                    },
                    success: function(response) {
                        if (response.success) {
                            location.reload();
                        } else {
                            alert('Terjadi kesalahan saat mengupdate status.');
                        }
                    }
                });
            });
        });
    </script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\sikatu\sikatu\resources\views/admin/ujian.blade.php ENDPATH**/ ?>